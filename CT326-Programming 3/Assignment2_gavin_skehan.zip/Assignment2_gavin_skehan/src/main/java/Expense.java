import org.joda.money.CurrencyUnit;
import org.joda.money.Money;

import java.time.LocalDate;

public class Expense {
    private LocalDate date;
    private String description;
    private ExpenseCategory category;
    private Money amount;
    private boolean approved;

    public Expense(LocalDate date, String description, ExpenseCategory category, Money amount){
        this.date = date;
        this.description = description;
        this.category = category;
        this.amount = amount;
        this.approved = false;
    }

    // Getter methods for each attribute

    public LocalDate getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public ExpenseCategory getCategory() {
        return category;
    }

    public Money getAmount() {
        return amount;
    }

    public String getLabel() {
        return category.toString();
    }

    public CurrencyUnit getCurrency() {
        return amount.getCurrencyUnit();
    }

    public void approve(){
        approved = true;
    }

    @Override
    public String toString() {
        return "Expense{" +
                "date=" + date +
                ", description='" + description + '\'' +
                ", category=" + category +
                ", amount=" + amount +
                '}';
    }
}
