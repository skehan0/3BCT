import org.joda.money.Money;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class PrinterByLabel implements ExpensePrinter {
    @Override
    public void printExpenses(List<Expense> expenses) {
        // Create a map to organize expenses by label
        Map<String, List<Expense>> expensesByLabel = new HashMap<>();

        // Group expenses by label
        for (Expense expense : expenses) {
            String label = expense.getLabel();
            expensesByLabel.putIfAbsent(label, new ArrayList<>());

            // Store the list in a variable for improved readability
            List<Expense> expensesForLabel = expensesByLabel.get(label);
            expensesForLabel.add(expense);
        }

        // Print expenses by label
        for (String label : expensesByLabel.keySet()) {
            System.out.println(label);

            // Retrieve the list from the variable
            List<Expense> expensesForLabel = expensesByLabel.get(label);

            for (Expense expense : expensesForLabel) {
                Money amount = expense.getAmount();
                String currencyCode = amount.getCurrencyUnit().getCode();
                double amountValue = amount.getAmount().doubleValue();

                System.out.println(String.format(
                        "%s: %s - %s - %s %.2f",
                        expense.getDate(),
                        expense.getDescription(),
                        label,
                        currencyCode,
                        amountValue
                ));
            }
        }
    }
}
