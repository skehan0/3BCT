import org.joda.money.CurrencyUnit;
import org.joda.money.Money;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExpensesPortal {
    private List<Expense> expenses;

    public ExpensesPortal() {
        expenses = new ArrayList<>();
    }

    // Method to submit a new expense
    public void submitExpense(Expense expense) {
        expenses.add(expense);
    }

    // Method to print expenses
    public void printExpenses(ExpensePrinter printer) {
        printer.printExpenses(expenses);
    }

    public static Money convertToEUR(BigDecimal amount, CurrencyUnit currency) {
        BigDecimal exchangeRate = new BigDecimal("0.85"); // 1 USD = 0.85 EUR

        // Create Money object based on the input amount and currency
        Money money = Money.of(currency, amount);

        // Convert the input amount to EUR using the exchange rate and rounding mode
        Money convertedAmount = money.convertedTo(CurrencyUnit.EUR, exchangeRate, RoundingMode.HALF_UP);

        return convertedAmount;
    }


    // Static method to sum expenses in EUR and USD
    public static Money sumExpenses(List<Expense> expenses) {
        Money totalEUR = Money.zero(CurrencyUnit.EUR);

        for (Expense expense : expenses) {
            if (expense.getCurrency() == CurrencyUnit.USD) {
                // Convert USD expenses to EUR before adding
                totalEUR = totalEUR.plus(convertToEUR(expense.getAmount().getAmount(), CurrencyUnit.USD));
            } else {
                totalEUR = totalEUR.plus(expense.getAmount());
            }
        }

        return totalEUR;
    }

    // Main method for creating expenses
    public static void main(String[] args) {
        ExpensesPortal portal = new ExpensesPortal();

        Expense expense1 = new Expense(
                LocalDate.parse("2022-09-20"),
                "Dell 17-inch monitor",
                ExpenseCategory.EQUIPMENT,
                Money.parse("USD 540.00")
        );
        expense1.approve();

        Expense expense2 = new Expense(
                LocalDate.parse("2022-09-23"),
                "Flight to Glasgow",
                ExpenseCategory.TRAVEL_AND_SUBSISTENCE,
                Money.parse("EUR 270.59")
        );
        expense2.approve();

        Expense expense3 = new Expense(
                LocalDate.parse("2022-09-21"),
                "Java for Dummies",
                ExpenseCategory.OTHER,
                Money.parse("EUR 17.99")
        );
        expense3.approve();

        // submit expenses to the portal
        portal.submitExpense(expense1);
        portal.submitExpense(expense2);
        portal.submitExpense(expense3);

        // Calculate the total expenses in EUR
        Money totalExpenses = sumExpenses(portal.expenses);


        // Call printExpenses with lambda expression to implement printer
        portal.printExpenses(expensesToPrint -> {
            System.out.println("Sample output: ");
            expensesToPrint.forEach(expense -> System.out.println(expense));
        });

        // Call printExpenses with an anonymous inner class
        portal.printExpenses(new ExpensePrinter() {
            @Override
            public void printExpenses(List<Expense> expenses) { // Use printExpenses, not print
                int totalExpenseCount = expenses.size(); // No need to cast to List<Expense>
                System.out.println("\nSample output:");
                System.out.println("There are " + totalExpenseCount + " expenses in the system totaling to a value of " + totalExpenses);
            }
        });

        System.out.println("\nSample Output");
        // Create a PrinterByLabel instance
        PrinterByLabel printerByLabel = new PrinterByLabel();

        // Add your expenses to the PrinterByLabel instance
        printerByLabel.printExpenses(portal.expenses);

    }
}
