import java.util.List;

interface ExpenseItem {
    String getDate();
    String getDescription();
    String getLabel();
    double getAmount();
}

interface ExpensePrinter {
    void printExpenses(List<Expense> expenses);
}