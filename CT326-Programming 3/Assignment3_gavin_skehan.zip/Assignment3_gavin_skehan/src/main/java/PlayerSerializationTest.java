/*
 * Gavin Skehan
 * 21440824
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * This class contains JUnit tests for the serialization and deserialization of Player objects.
 */
public class PlayerSerializationTest {
    private List<Player> players;

    /**
     * Test the serialization and deserialization of Player objects.
     */
    @Test
    void testPlayerSerialization() {
        // Serialize players to a file
        serializePlayers("players.ser");

        // Deserialize players from the file
        List<Player> deserializedPlayers = deserializePlayers("players.ser");

        assertEquals(players.size(), deserializedPlayers.size());

        for (int i = 0; i < players.size(); i++) {
            Player originalPlayer = players.get(i);
            Player deserializedPlayer = deserializedPlayers.get(i);

            assertEquals(originalPlayer.getId(), deserializedPlayer.getId());
            assertEquals(originalPlayer.getUsername(), deserializedPlayer.getUsername());
            assertEquals(originalPlayer.getCountry(), deserializedPlayer.getCountry());
            assertEquals(originalPlayer.getJoinDate(), deserializedPlayer.getJoinDate());

            // Compare achievements
            List<Achievement> originalAchievements = originalPlayer.getAchievements();
            List<Achievement> deserializedAchievements = deserializedPlayer.getAchievements();

            assertEquals(originalAchievements.size(), deserializedAchievements.size());

            for (int j = 0; j < originalAchievements.size(); j++) {
                Achievement originalAchievement = originalAchievements.get(j);
                Achievement deserializedAchievement = deserializedAchievements.get(j);

                assertEquals(originalAchievement.getAchievementName(), deserializedAchievement.getAchievementName());
                assertEquals(originalAchievement.getDescription(), deserializedAchievement.getDescription());
                assertEquals(originalAchievement.getDateOfAward(), deserializedAchievement.getDateOfAward());
            }
        }
    }
    /**
     * Initializes a list of Player objects with achievements for testing.
     */
    @BeforeEach
    void initializePlayers() {
        players = new ArrayList<>();

        // Create five Player objects with Achievement lists
        for (int i = 0; i < 4; i++) {
            // Create a Player with relevant attributes
            Player player = new Player("Player" + i, "Username" + i, new Country("Country" + i), LocalDate.now(), new ArrayList<>());

            // Populate Player's achievements
            Achievement achievement1 = new Achievement(
                    "Olympic Gold Medal - 200 meter breaststroke",
                    "Awarded on 19/07/2022",
                    LocalDate.of(2022, 7, 19)
            );
            Achievement achievement2 = new Achievement(
                    "Player of the Tournament - Irish Open",
                    "Awarded on 10/05/2021",
                    LocalDate.of(2021, 5, 10)
            );
            Achievement achievement3 = new Achievement(
                    "Grand Prix - Monaco",
                    "Awarded on 17/06/2023",
                    LocalDate.of(2023, 6, 17)
            );
            Achievement achievement4 = new Achievement(
                    "All Ireland Hurling - GAA",
                    "Awarded on 28/08/2002",
                    LocalDate.of(2002, 8, 28)
            );
            Achievement achievement5 = new Achievement(
                    "Cross Fit Champion - Aussie Cross Fit Games",
                    "Awarded on 1/01/2009",
                    LocalDate.of(2009, 1, 1)
            );

            // Add achievements directly to the player's achievements list
            player.getAchievements().add(achievement1);
            player.getAchievements().add(achievement2);
            player.getAchievements().add(achievement3);
            player.getAchievements().add(achievement4);
            player.getAchievements().add(achievement5);

            players.add(player);
        }
    }
    private void serializePlayers(String filename) {
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(filename))) {
            os.writeObject(players);
        } catch (IOException e) {
            e.printStackTrace();
            fail("Serialization failed.");
        }
    }
    private List<Player> deserializePlayers(String filename) {
        try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(filename))) {
            return (List<Player>) is.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            fail("Deserialization failed.");
            return new ArrayList<>(); // Return an empty list in case of failure
        }
    }
}
