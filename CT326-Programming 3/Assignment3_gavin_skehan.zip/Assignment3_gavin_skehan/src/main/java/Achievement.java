/*
 * Gavin Skehan
 * 21440824
 * */

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Serializable class representing an achievement earned by a player.
 */
public class Achievement implements Serializable {
    private String achievementName;
    private String description;
    private LocalDate dateOfAward;

    /**
     * Constructs an Achievement object with the specified attributes.
     *
     * @param achievementName The name of the achievement.
     * @param description     A description of the achievement.
     * @param dateOfAward     The date on which the achievement was awarded.
     */
    public Achievement(String achievementName, String description, LocalDate dateOfAward) {
        this.achievementName = achievementName;
        this.description = description;
        this.dateOfAward = dateOfAward;
    }

    public String getAchievementName() {
        return achievementName;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDateOfAward() {
        return dateOfAward;
    }

    @Override
    public String toString() {
        return "Achievement{" +
                "achievementName='" + achievementName + '\'' +
                ", description='" + description + '\'' +
                ", dateOfAward=" + dateOfAward +
                '}';
    }
}
