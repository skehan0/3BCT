/*
 * Gavin Skehan
 * 21440824
 * */

import java.io.Serializable;

/**
 * Serializable class representing a country.
 */
public class Country implements Serializable {
    private String name;

    /**
     * Constructs a Country object with the specified name.
     *
     * @param name The name of the country.
     */
    public Country(String name) {
        this.name = name;
    }

    /**
     * Gets the name of the country.
     *
     * @return The name of the country.
     */
    public String getName() {
        return name;
    }

    /**
     * Compares this country to another object for equality.
     *
     * @param obj The object to compare to.
     * @return {@code true} if the objects are equal, {@code false} otherwise.
     */
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Country country = (Country) obj;
        return name.equals(country.name);
    }
}
