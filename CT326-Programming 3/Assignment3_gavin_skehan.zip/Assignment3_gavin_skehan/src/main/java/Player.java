/*
 * Gavin Skehan
 * 21440824
 * */

import java.io.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

/**
 * Serializable class representing a player.
 */
public class Player implements Serializable {
    private String id;
    private String username;
    private Country country;
    private LocalDate joinDate;
    private List<Achievement> achievements;

    /**
     * Constructs a Player object with the specified attributes.
     *
     * @param id           The player's unique identifier.
     * @param username     The player's username.
     * @param country      The player's country.
     * @param joinDate     The player's join date.
     * @param achievements The list of achievements associated with the player.
     */
    public Player(String id, String username, Country country, LocalDate joinDate, List<Achievement> achievements) {
        this.id = id;
        this.username = username;
        this.country = country;
        this.joinDate = joinDate;
        this.achievements = achievements;
    }

    /**
     * Gets the player's unique identifier.
     *
     * @return The player's identifier.
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the player's username.
     *
     * @return The player's username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the player's country.
     *
     * @return The player's country.
     */
    public Country getCountry() {
        return country;
    }

    /**
     * Gets the player's join date.
     *
     * @return The player's join date.
     */
    public LocalDate getJoinDate() {
        return joinDate;
    }

    /**
     * Gets the list of achievements associated with the player.
     *
     * @return The list of player achievements.
     */
    public List<Achievement> getAchievements() {
        return achievements;
    }

    /**
     * Sets the list of achievements associated with the player.
     *
     * @param achievements The list of player achievements to set.
     */
    public void setAchievements(List<Achievement> achievements) {
        this.achievements = achievements;

    }

    /**
     * Custom serialization method to write object attributes to an ObjectOutputStream.
     * Serializes the player's country name and writes achievements to a CSV file.
     *
     * @param os The ObjectOutputStream to write to.
     * @throws IOException If an I/O error occurs during serialization.
     */
    @Serial
    private void writeObject(ObjectOutputStream os) throws IOException {
        os.defaultWriteObject();
        os.writeObject(country.getName());

        // Create and write to the CSV file
        try (FileWriter csvWriter = new FileWriter("achievements.csv")) {
            for (Achievement achievement : achievements) {
                String serializedData = achievement.getAchievementName() + "," + achievement.getDescription() + "," + achievement.getDateOfAward();
                csvWriter.write(serializedData + "\n");
            }
        }
    }

    /**
     * Custom deserialization method to read object attributes from an ObjectInputStream.
     * Reads the player's country name and achievements from a CSV file.
     *
     * @param is The ObjectInputStream to read from.
     * @throws IOException            If an I/O error occurs during deserialization.
     * @throws ClassNotFoundException If the required class is not found during deserialization.
     */
    @Serial
    private void readObject(ObjectInputStream is) throws IOException, ClassNotFoundException {
        is.defaultReadObject();
        String countryName = (String) is.readObject();
        country = new Country(countryName);

        File achievementsFile = new File("achievements.csv");
        if (!achievementsFile.exists()) {
            // Handle the case where the file does not exist
            throw new IOException("Achievements file not found.");
        }

        try (Scanner scanner = new Scanner(achievementsFile)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length >= 4) { // Assuming there is an ID before achievement attributes
                    String playerId = parts[0];
                    String achievementName = parts[1];
                    String description = parts[2];
                    LocalDate dateOfAward = LocalDate.parse(parts[3]);
                    Achievement achievement = new Achievement(achievementName, description, dateOfAward);
                    // Ensure the achievement belongs to this player based on the player ID
                    if (playerId.equals(getId())) {
                        achievements.add(achievement);
                    }
                }
            }
        }
    }
}
