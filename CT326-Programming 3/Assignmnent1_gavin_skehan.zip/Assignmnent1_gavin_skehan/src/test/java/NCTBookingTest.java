import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDateTime;

/*
 * Gavin Skehan
 * 21440824
 */

public class NCTBookingTest {
    private TestCentre testCentre;
    private NCTBooking nctBooking;

    @BeforeEach
    public void setup(){
        testCentre = new TestCentre("Portlaoise", "Lismard Park, Timahoe Road, Laois");
        nctBooking = new NCTBooking("16-WH-59741", testCentre, LocalDateTime.now());
        LocalDateTime dateTime = LocalDateTime.of(2023, 9, 19, 13, 00);

    }

    @Test
    public void testGetTestCentre(){
        // use getTestCentre() to query test centre
        TestCentre queryTestCentre = nctBooking.getTestCentre();

        // verify query matches test centre
        assertEquals(testCentre, queryTestCentre);
    }

    @Test
    public void testGetRegistrationNumber(){
        // get registration number using getter method
        String initialRegistrationNumber = nctBooking.getRegistrationNumber();

        // verify initial registration matches one set
        assertEquals("16-WH-59741", initialRegistrationNumber);
    }

    @Test
    public void testEditRegistrationNumber(){
        // set registration
        nctBooking.setRegistrationNumber("17-LS-12345");

        // call the edit method from nct booking
        String editRegistrationNumber = nctBooking.getRegistrationNumber();
        assertEquals("17-LS-12345", editRegistrationNumber);
    }

//    @Test
//    public void testValidRegistrationNumber() throws InvalidRegistrationNumberException {
//        String validRegistrationNumber = "AB-WH-43212";
//        String result = nctBooking.validateRegistrationNumber(validRegistrationNumber);
//        assertEquals(validRegistrationNumber, result);
//    }

    @Test
    public void testNoDateNoTime(){
        // create a booking with a null time and date
        NCTBooking booking = new NCTBooking("16-WH-59741", testCentre, null);

        // verify no date or time
        assertNull(booking.getDateTime());
    }

    @Test
    public void testBookingWithValidDataTime(){
        // set date time to 10 days from now
        LocalDateTime dateTime = LocalDateTime.now().plusDays(10);

        // create the new booking
        NCTBooking booking = new NCTBooking("16-WH-59741", testCentre, dateTime);

        // verify booking details
        assertEquals("16-WH-59741", booking.getRegistrationNumber());
        assertEquals(testCentre, booking.getTestCentre());
        assertEquals(dateTime, booking.getDateTime());
    }

    @Test
    public void testBookingWithInvalidDateTime(){
        // invalid date (Past)
        LocalDateTime dateTime = LocalDateTime.now().minusDays(1);

        // throw exception for invalid datetime
        assertThrows(InvalidBookingException.class, () -> new NCTBooking("16-WH-59741", testCentre, dateTime));
    }

    @Test
    public void testUniqueBookingID(){
        // create new bookings to compare unique ids
        NCTBooking booking1 = new NCTBooking("11-KR-11111", testCentre, LocalDateTime.now());
        NCTBooking booking2 = new NCTBooking("22-KK-22222", testCentre, LocalDateTime.now());
        NCTBooking booking3 = new NCTBooking("23-LS-33333", testCentre, LocalDateTime.now());

        // call the getter method from the nct booking
        int bookingId1 = booking1.getBookingId();
        int bookingId2 = booking2.getBookingId();
        int bookingId3 = booking3.getBookingId();

        // compare the bookings
        assertNotEquals(bookingId1, bookingId2);
        assertNotEquals(bookingId1, bookingId3);
        assertNotEquals(bookingId2, bookingId3);
    }

    @Test
    public void testToStringMethod(){
        String booking = nctBooking.toString();

        // define expected format of the sting
        String expectedFormat = "Booking ID Number: \\d+\n" +
                "Registration Number: 16-WH-59741 \n" +
                "Test Centre: Portlaoise \n" +
                "Address: Lismard Park, Timahoe Road, Laois\n" +
                "Date and Time: Tuesday, 19 September 2023 at 13:00";
    }
}
