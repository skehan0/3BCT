import java.time.LocalDateTime;

/*
 * Gavin Skehan
 * 21440824
 */
public interface NCTBookingSlotWebservice {
    public LocalDateTime getBookingDateTime(TestCentre testCentre);
}
