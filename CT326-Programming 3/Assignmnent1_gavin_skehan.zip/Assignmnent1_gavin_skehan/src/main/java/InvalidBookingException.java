/*
 * Gavin Skehan
 * 21440824
 */
public class InvalidBookingException extends RuntimeException{
    public InvalidBookingException(String message) {
        super(message);
    }
}
