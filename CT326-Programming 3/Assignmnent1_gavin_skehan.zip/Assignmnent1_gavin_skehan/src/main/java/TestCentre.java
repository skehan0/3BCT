/*
 * Gavin Skehan
 * 21440824
 */

public class TestCentre {
    private String name;
    private String address;

    public TestCentre(String name, String getAddress){
        this.name = name;
        this.address = address;
    }

    // getter methods
    public String getName(){
        return name;
    }

    public String getAddress(){
        return address;
    }
}
