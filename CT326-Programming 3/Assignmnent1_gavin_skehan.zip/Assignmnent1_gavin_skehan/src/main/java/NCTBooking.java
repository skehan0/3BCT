import java.time.LocalDateTime;

/*
* Gavin Skehan
* 21440824
*/

public class NCTBooking {
    private static int bookingIdCounter = 1;
    public int bookingId;
    public String registrationNumber;
    public TestCentre testCentre;
    public LocalDateTime dateTime;

    public NCTBooking(String vehicleRegistration, TestCentre testCentre, LocalDateTime dateTime){
        if (dateTime != null && dateTime.isBefore(LocalDateTime.now().minusSeconds(30))){
            throw new InvalidBookingException("Invalid date and time, booking can't be in the past.");
        }
        this.bookingId = bookingIdCounter++;
        this.registrationNumber = vehicleRegistration;
        this.testCentre = testCentre;
        this.dateTime = dateTime;
    }

    public String validateRegistrationNumber(String validRegistrationNumber) throws InvalidRegistrationNumberException {
        String validReg = "^[A-Z]{2}-\\d{2}-\\d{5}$";

        // check if registration is valid
        if(registrationNumber.matches(validReg)){
            return registrationNumber;
        }else {
            // throw exception
            throw new InvalidRegistrationNumberException("Invalid registration number, check formatting." + registrationNumber);
        }
    }

    public int getBookingId(){
        return bookingId;
    }

    public String getRegistrationNumber(){
        return registrationNumber;
    }
    public void setRegistrationNumber(String editRegistrationNumber){
        this.registrationNumber = editRegistrationNumber;
    }

    public TestCentre getTestCentre(){
        return testCentre;
    }

    public LocalDateTime getDateTime(){
        return dateTime;
    }

    @Override
    public String toString() {
        return "Booking ID Number: " + bookingId + "\n" +
                "Registration Number: " + registrationNumber + "\n" +
                "Test Centre: " + testCentre.getName() + "\n" +
                "Address: " + testCentre.getAddress() + "\n" +
                "Date and Time: " + dateTime;
    }


}
