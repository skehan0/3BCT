/*
 * Gavin Skehan
 * 21440824
 */
public class InvalidRegistrationNumberException extends RuntimeException {
    // invalid registration exception
    public InvalidRegistrationNumberException(String message) {
        super(message);
    }
}
